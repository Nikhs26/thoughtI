package com.nikhil;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.nikhil.beans.Item;
import com.nikhil.beans.Orders;
import com.nikhil.repo.ItemRepo;
import com.nikhil.repo.OrderRepo;

@SpringBootTest
class ThoughtIRestapiApplicationTests {

	@Autowired
	ItemRepo itemRepo;
	
	@Autowired
	OrderRepo orderRepo;
	
	@Test
	public void itemAdded() {
		Item i = new Item("Mobile",1,2);
		itemRepo.save(i);
		assertNotNull(itemRepo.findById((long)i.getItemId()).get());
	}
	
	@Test
	public void orderAdded() {
		Orders o = new Orders("01/01/2021","In progress");
		orderRepo.save(o);
		assertNotNull(orderRepo.findById((long)o.getOrderId()).get());
	}

}
