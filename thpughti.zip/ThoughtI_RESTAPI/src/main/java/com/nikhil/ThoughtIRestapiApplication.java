package com.nikhil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThoughtIRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThoughtIRestapiApplication.class, args);
	}

}
