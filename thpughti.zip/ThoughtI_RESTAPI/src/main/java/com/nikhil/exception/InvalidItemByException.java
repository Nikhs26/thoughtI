package com.nikhil.exception;

public class InvalidItemByException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidItemByException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidItemByException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidItemByException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidItemByException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
