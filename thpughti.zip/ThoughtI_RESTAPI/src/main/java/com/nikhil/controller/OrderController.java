package com.nikhil.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nikhil.beans.Orders;
import com.nikhil.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping
	public ResponseEntity<List<Orders>> getFindAllOrders() {
		List<Orders> orders = orderService.findAllOrders();
		ResponseEntity<List<Orders>> responseEntity = new ResponseEntity<List<Orders>>(orders,HttpStatus.OK);
		return responseEntity;
	}
	
//	@GetMapping("/{id}")
//	public ResponseEntity<List<Item>> findAllPages(@PathVariable("id") long id) throws InvalidOrderByException{
//		List<Item> items = orderService.findOrdersById(id).getOrders();
//		ResponseEntity<List<Item>> responseEntity = new ResponseEntity<List<Item>>(items, HttpStatus.OK);
//		return responseEntity;
//	}
	
	@PostMapping
	public ResponseEntity<Orders> saveBook(@RequestBody Orders order) {
		Orders orderSaved = orderService.saveOrder(order);
		ResponseEntity<Orders> responseEntity = new ResponseEntity<Orders>(orderSaved, HttpStatus.CREATED);
		return responseEntity;
	}
}
