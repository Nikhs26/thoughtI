package com.nikhil.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nikhil.beans.Item;
import com.nikhil.beans.Orders;
import com.nikhil.exception.InvalidItemByException;
import com.nikhil.service.ItemService;

@RestController
@RequestMapping("/order")
public class ItemController {

	@Autowired
	ItemService itemService;
	
	@GetMapping
	public ResponseEntity<List<Item>> getFindAllItems() {
		List<Item> items = itemService.findAllItems();
		ResponseEntity<List<Item>> responseEntity = new ResponseEntity<List<Item>>(items,HttpStatus.OK);
		return responseEntity;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<List<Orders>> findAllPages(@PathVariable("id") long id) throws InvalidItemByException{
		List<Orders> orders = itemService.findItemsById(id).getOrders();
		ResponseEntity<List<Orders>> responseEntity = new ResponseEntity<List<Orders>>(orders, HttpStatus.OK);
		return responseEntity;
	}
	
	@PostMapping
	public ResponseEntity<Item> saveBook(@RequestBody Item item) {
		Item itemSaved = itemService.saveItem(item);
		ResponseEntity<Item> responseEntity = new ResponseEntity<Item>(itemSaved, HttpStatus.CREATED);
		return responseEntity;
	}

	
}
